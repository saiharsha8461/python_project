print("This Ecom Package's database module")
