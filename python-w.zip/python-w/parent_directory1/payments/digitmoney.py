print("This Payments Package's digitmoney module")
