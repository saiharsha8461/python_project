def smaller(a, b):
	
	print(min(a, b)
)