class Relative21:
	
	def equalto(self, a, b):
		
		if a==b:
			
			print('True')
		
		else:
			
			print('False')
