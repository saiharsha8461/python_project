def greater(a, b):
	
	print(max(a, b)
)