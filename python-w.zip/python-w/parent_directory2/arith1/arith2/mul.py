class Arith21:
	
	def mul(self, a, b):
		
		print(a*b)
