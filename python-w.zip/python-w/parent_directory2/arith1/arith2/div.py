class Arith22:
	
	def div(self, a, b):
		
		print(a/b
)