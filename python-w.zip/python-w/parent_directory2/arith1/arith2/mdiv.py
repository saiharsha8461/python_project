class Arith23:
	 
	def mdiv(self, a, b):
		
		print(a%b)
