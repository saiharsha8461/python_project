def sub(a, b):
	
	print(a-b)
