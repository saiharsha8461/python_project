from arith1 import add, sub
from arith1.arith2 import mdiv, div, mul
from relative1 import greater, smaller
from relative1.relative2 import equalto
while(True):
        print('1.Arithmetic\n2.Relative\n3.Quit')
        try:
                c = int(input("Choose your option: "))
        except:
                print('please enter a valid number for option')
        if c == 1:
                while(True):
                        print('1.Addition\n 2.Subtraction\n3.Multiplication\n4.Division\n5.Modulo\n6.Quit')      
                        try:
                                choice = int(input("Choose your option: "))
                        except:
                                print('please enter a valid number for option')
                        if choice == 1:
                                a=int(input('Enter the first number: '))
                                b=int(input('Enter the second number: '))
                                add.add(a, b)
                            
                        elif choice == 2:
                                a, b= int(input('Enter the first number: ')), int(input('Enter the second number: '))
                                sub.sub(a, b)
                        elif choice == 3:
                                a, b= int(input('Enter the first number: ')), int(input('Enter the second number: '))
                                x=mul.Arith21()   	
                                x.mul(a, b)
                        elif choice == 4:
                                a, b= int(input('Enter the first number: ')), int(input('Enter the second number: '))
                                y=div.Arith22()   	
                                y.div(a, b)
                        elif choice == 5:
                                a, b= int(input('Enter the first number: ')), int(input('Enter the second number: '))
                                z=mdiv.Arith23()   	
                                z.mdiv(a, b)
                        elif choice==6:
                                break
                        else:
                                print("please choice a valid option from 1 to 6")
                                choice=0
        elif c == 2:
                while(True):
                        print('1.Greater than\n2.Less than\n3.Equal to\n4.Quit')
                        try:
                                ch = int(input("Choose your option: "))
                        except:
                                print('please enter a valid number for option')
                        if ch == 1:
                                a, b=int(input('Enter the first number: ')), int(input('Enter the second number: '))
                                greater.greater(a, b)
                        elif ch == 2:
                                a, b= int(input('Enter the first number: ')), int(input('Enter the second number: '))
                                smaller.smaller(a, b)
                        elif ch == 3:
                                a, b= int(input('Enter the first number: ')), int(input('Enter the second number: '))
                                w=equalto.Relative21()   	
                                w.equalto(a, b)
                        elif ch==4:
                                break
                        else:
                                print("please choice a valid option from 1 to 4")
                                ch=0
        elif c==3:
                break
        else:
                print("please choice a valid option from 1 to 3")
                choice=0

			

